import React from 'react'
import { Outlet } from 'react-router';
import EventsNavigation from '../components/EventsNavigation';

const EventLayout = () => {
  return (
    <>
        <EventsNavigation></EventsNavigation>
        <Outlet />
    </>
  )
}

export default EventLayout;

