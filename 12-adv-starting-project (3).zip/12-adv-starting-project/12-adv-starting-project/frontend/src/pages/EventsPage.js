import React from 'react'
import { Link } from 'react-router-dom';

function EventsPage() {

    const DUMMY_EVENTS = [
        { id: 1, name: "Hochzeit", place: "Viernheim" },
        { id: 2, name: "Party", place: "Worms" },
        { id: 3, name: "Techno", place: "Frankfurt" }
    ]
    return (
        <ul>
            { DUMMY_EVENTS.map((ev) => {
                return (
                    <li key={ev.id}><Link to={`./${ev.name}`}>{ev.name}</Link></li>
                )
            }) }
        </ul>
    )
}

export default EventsPage